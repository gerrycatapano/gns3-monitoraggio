@echo off
setlocal
cd /d "%~dp0"
echo Sola raccolta Wazuh - nessuna scansione di memoria
echo Usare Esegui come amministratore.
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 "%~dp0orchestratore_hr_gns3.py" monitor --config "%~dp0config_hr.json" --sensors none
goto finish
:use_python
where python >nul 2>nul
if errorlevel 1 goto missing_python
python "%~dp0orchestratore_hr_gns3.py" monitor --config "%~dp0config_hr.json" --sensors none
goto finish
:missing_python
echo Python non trovato. Usare Python 3.10 o successivo.
:finish
echo.
echo Programma terminato. Leggere eventuali errori sopra.
pause
endlocal
