﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][int]$TargetPid,
    [Parameter(Mandatory = $true)][ValidatePattern('^[A-Za-z]:\\')][string]$TargetModule,
    [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][string]$TargetFunction,
    [Parameter(Mandatory = $true)][ValidatePattern('^T[0-9]{4}\.[0-9]{3}$')][string]$TechniqueId,
    [string]$PeSievePath = 'C:\Tools\pe-sieve64.exe',
    [string]$OutputLog = 'C:\ProgramData\ThesisTelemetry\memory_integrity.json',
    [string]$WorkRoot = 'C:\ProgramData\ThesisTelemetry\pe-sieve-work',
    [string]$RunId = '',
    [string]$ResultPath = '',
    [ValidateRange(1,120)][int]$TimeoutSeconds = 15,
    [ValidateRange(0,2000)][int]$ReadinessTimeoutMilliseconds = 500,
    [bool]$ScanThreads = $true,
    [ValidateRange(0,3)][int]$ObfuscMode = 3,
    [string]$ExpectedProcessStartUTC = '',
    [hashtable[]]$AdditionalTargets = @()
)

$ErrorActionPreference = 'Stop'

function Get-PeSieveArguments {
    <#
    .SYNOPSIS
        Build a bounded, explicitly configured PE-sieve CLI argument string.
    .DESCRIPTION
        /threads inspects thread call stacks; /obfusc 0..3 adds obfuscated-memory
        heuristics. Neither makes a scan a proof of a particular evasion technique.
        No /minidmp option is enabled.
    #>
    param([int]$ProcessId, [string]$ReportDirectory,
          [bool]$EnableThreads, [ValidateRange(0,3)][int]$ObfuscationMode)
    $arguments = '/pid ' + $ProcessId + ' /report L /dir "' + $ReportDirectory + '"'
    if ($EnableThreads) { $arguments += ' /threads' }
    if ($ObfuscationMode -gt 0) { $arguments += ' /obfusc ' + $ObfuscationMode }
    return $arguments
}

function Initialize-MemoryOutputPump {
    # Compatibility entry point. StreamReader.ReadToEndAsync needs no C# helper.
}

function Get-MemoryOutputTaskText {
    param($ReadTask, [int]$TimeoutMs = 3000)
    try {
        if (-not $ReadTask.Wait($TimeoutMs)) { throw 'SCANNER_OUTPUT_TIMEOUT' }
        return [string]$ReadTask.GetAwaiter().GetResult()
    } catch {
        $cause = $_.Exception.GetBaseException()
        throw ('SCANNER_OUTPUT_READ_FAILED: ' + $cause.GetType().FullName + ': ' + $cause.Message)
    }
}

function Find-PeSieveProcessDirectory {
    param([string]$ScanDirectory, [int]$ProcessId)
    $expected = Join-Path $ScanDirectory ('process_' + $ProcessId)
    if (Test-Path -LiteralPath (Join-Path $expected 'scan_report.json')) { return $expected }
    # Allow report placement differences only when one report proves the PID.
    $matches = @()
    foreach ($file in @(Get-ChildItem -LiteralPath $ScanDirectory -Filter 'scan_report.json' -File -Recurse -ErrorAction Stop)) {
        try {
            $report = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json -ErrorAction Stop
            if ($null -ne $report.pid -and [int]$report.pid -eq $ProcessId) { $matches += $file.DirectoryName }
        } catch {
            throw ('SCAN_REPORT_INVALID: ' + $_.Exception.GetBaseException().Message)
        }
    }
    if ($matches.Count -ne 1) { throw ('SCAN_REPORT_LOCATION_UNRESOLVED: matching reports=' + $matches.Count) }
    return $matches[0]
}

function New-MemoryObservation {
    param([int]$ProcessId, [string]$RunIdentifier)
    return [ordered]@{
        schema_version = '2.2'; timestamp = $null; source = 'memory_integrity'; sensor = 'pe-sieve'
        run_id = $RunIdentifier; scan_id = [guid]::NewGuid().ToString('N'); scan_group_id = $null; pid = $ProcessId
        target_module = $TargetModule; target_function = $TargetFunction; target_technique_id = $TechniqueId
        generic_status = 'SENSOR_ERROR'
        image = $null; process_start_utc = $null; status = 'SENSOR_ERROR'; scan_completed = $false
        total_scanned = $null; total_suspicious = $null; hooked = $null; scan_errors = $null
        module = $null; module_base = $null; module_modified = $null; patch_count = $null
        function = $null; patch_rva = $null; patch_size = $null; target_module_observed = $null
        target_module_ready = $null; target_coverage_evidence = 'UNKNOWN'; target_integrity_verified = $null; target_scan_completed = $null; scan_report_mode = 'LEGACY' 
        target_module_modified = $null; target_function_modified = $null; technique_observed = $null
        technique_id = $null; pe_exit_code = $null; scan_start_utc = $null; scan_end_utc = $null
        scan_report = $null; dump_report = $null; tag_file = $null; raw_output = $null
        work_dir = $null; error = $null; warnings = @(); publication_status = 'NOT_ATTEMPTED'; publication_error = $null
        scan_threads_enabled = $ScanThreads; scan_obfusc_mode = $ObfuscMode
    }
}

function Write-SharedJsonLine {
    param([string]$Path, [string]$Json)
    $parent = Split-Path -Parent $Path
    if ($parent) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Json + [Environment]::NewLine)
    # Wazuh may hold a read handle. Retry transient writer contention, bounded.
    for ($attempt = 0; $attempt -lt 5; $attempt++) {
        $stream = $null
        try {
            $stream = [System.IO.FileStream]::new($Path, [System.IO.FileMode]::Append,
                [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite)
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Flush()
            return
        } catch [System.IO.IOException] {
            if ($attempt -eq 4) { throw }
            Start-Sleep -Milliseconds 100
        } finally {
            if ($null -ne $stream) { $stream.Dispose() }
        }
    }
}

function Convert-PeSieveEvidenceCore {
    param([System.Collections.IDictionary]$Event, [string]$ConsoleText, [string]$ProcessDirectory)
    # This function parses evidence only; it never uses the payload name or tier.
    if ($ConsoleText -notmatch '(?im)SUMMARY\s*:') { throw 'SUMMARY_MISSING' }
    foreach ($item in @(@('total_scanned','Total scanned'), @('total_suspicious','Total suspicious'), @('hooked','Hooked'))) {
        if ($ConsoleText -notmatch ('(?im)^\s*' + $item[1] + '\s*:\s*(\d+)\s*$')) {
            throw ('SUMMARY_FIELD_MISSING:' + $item[0])
        }
        $Event[$item[0]] = [int]$Matches[1]
    }
    if ($Event.total_scanned -le 0) { throw 'NO_MODULES_SCANNED' }
    if ($ConsoleText -match '(?im)^\s*(?:\[!\]\s*)?Errors\s*:\s*(\d+)\s*$') { $Event.scan_errors = [int]$Matches[1] }
    $consoleErrorCount=$Event.scan_errors
    $scanPath = Join-Path $ProcessDirectory 'scan_report.json'
    $dumpPath = Join-Path $ProcessDirectory 'dump_report.json'
    $report = $null
    if (Test-Path -LiteralPath $scanPath) {
        $Event.scan_report = $scanPath
        $report = Get-Content -LiteralPath $scanPath -Raw | ConvertFrom-Json -ErrorAction Stop
        if ($null -eq $report.pid -or [int]$report.pid -ne $Event.pid) { throw 'REPORT_PID_MISMATCH' }
        if ($null -ne $report.scanned.errors) {
            if ($null -ne $consoleErrorCount -and [int]$report.scanned.errors -ne $consoleErrorCount) {
                throw 'ERROR_COUNT_REPORT_SUMMARY_MISMATCH'
            }
            $Event.scan_errors = [int]$report.scanned.errors
        }
    }
    if ($Event.scan_report_mode -eq 'ALL' -and $null -eq $report) { throw 'FULL_SCAN_REPORT_MISSING' }
    if ($Event.scan_report_mode -eq 'ALL' -and $null -eq $report.scanned.errors) { throw 'FULL_REPORT_ERROR_COUNT_MISSING' }
    if (Test-Path -LiteralPath $dumpPath) {
        $Event.dump_report = $dumpPath
        $dump = Get-Content -LiteralPath $dumpPath -Raw | ConvertFrom-Json -ErrorAction Stop
        if ($null -eq $dump.pid -or [int]$dump.pid -ne $Event.pid) { throw 'DUMP_PID_MISMATCH' }
    }
    # Official PE-sieve return codes: 0=info/help, 1=no suspicious, 2=suspicious.
    # A successful exit code alone never establishes scan completion/coverage.
    if ($null -ne $Event.pe_exit_code) {
        if ($Event.pe_exit_code -notin @(1,2)) { throw 'UNEXPECTED_PE_EXIT_CODE' }
        if (($Event.pe_exit_code -eq 1 -and $Event.total_suspicious -gt 0) -or
            ($Event.pe_exit_code -eq 2 -and $Event.total_suspicious -eq 0)) { throw 'EXIT_CODE_SUMMARY_MISMATCH' }
    }
    # Recompute coverage exclusively from this scanner's evidence. Never inherit
    # a readiness flag, including when replaying older records for validation.
    $Event.target_module_observed = $null
    $Event.target_module_modified = $null; $Event.target_function_modified = $null
    $Event.technique_observed = $null; $Event.patch_count = $null
    $Event.target_coverage_evidence = 'UNKNOWN'
    $expectedModule = $Event.target_module
    $scannedPaths = @([regex]::Matches($ConsoleText, '(?im)^\s*\[\*\]\s+Scanning:\s*(.+?)\s*$') |
        ForEach-Object { $_.Groups[1].Value.Trim() })
    if ($scannedPaths.Count -gt 0) {
        $Event.target_module_observed = @($scannedPaths | Where-Object { $_ -ieq $expectedModule }).Count -gt 0
        $Event.target_coverage_evidence = 'PE_SIEVE_CONSOLE'
    }
    $detachedPaths = @([regex]::Matches($ConsoleText, '(?im)^\s*\[!\]\s+Scanning detached:\s*(?:0x)?[0-9a-f]+\s*:\s*(.+?)\s*$') |
        ForEach-Object { $_.Groups[1].Value.Trim() })
    $detached = @($detachedPaths | Where-Object { $_ -ieq $expectedModule }).Count -gt 0
    if ($detached) { $Event.target_module_observed = $true; $Event.target_coverage_evidence = 'PE_SIEVE_CONSOLE_DETACHED' }
    $Event.target_integrity_verified = $null
    $coveredCode = @($report.scans | Where-Object {
        $null -ne $_.code_scan -and [string]$_.code_scan.module_file -ieq $expectedModule -and
        $null -ne $_.code_scan.status -and [int]$_.code_scan.status -in @(0,1) -and
        ($Event.scan_report_mode -ne 'ALL' -or [int]$_.code_scan.scanned_sections -gt 0)
    })
    if ($null -ne $Event.scan_errors -and $Event.scan_errors -gt 0) {
        # Global errors do not erase a uniquely verified target code scan.
        # Positive function evidence still requires the matching module tag below.
        if ($Event.scan_report_mode -ne 'ALL' -or $coveredCode.Count -ne 1) {
            throw 'INCOMPLETE_SCAN_ERRORS'
        }
        $base=[string]$coveredCode[0].code_scan.module
        $targetOtherErrors=@($report.scans | ForEach-Object { $_.PSObject.Properties.Value } | Where-Object {
            $null -ne $_.status -and [int]$_.status -notin @(0,1) -and
            (([string]$_.module_file -ieq $expectedModule) -or ($base -and [string]$_.module -ieq $base))
        })
        if ($targetOtherErrors.Count) { throw 'INCOMPLETE_SCAN_ERRORS' }
    }
    if ($coveredCode.Count -gt 0) {
        $Event.target_module_observed = $true; $Event.target_coverage_evidence = 'PE_SIEVE_CODE_SCAN'
        $Event.target_integrity_verified = $true
    }
    $canEstablishIntegrity = ($coveredCode.Count -gt 0) -or
        ($Event.scan_report_mode -ne 'ALL' -and -not $detached -and $Event.target_module_observed -eq $true)
    if ($Event.scan_report_mode -eq 'ALL' -and $coveredCode.Count -eq 0) {
        $Event.target_integrity_verified = $false
        $Event.warnings += 'TARGET_CODE_SCAN_NOT_VERIFIED'
    }
    if ($Event.total_suspicious -eq 0) {
        if (@($coveredCode | Where-Object { [int]$_.code_scan.status -ne 0 }).Count -gt 0) { throw 'CLEAN_TARGET_CODE_SCAN_CONTRADICTION' }
        if ($Event.hooked -ne 0) { throw 'INCONSISTENT_SUMMARY' }
        if (@($report.scans | Where-Object {
            $null -ne $_.code_scan -and [int]$_.code_scan.status -eq 1 -and [int]$_.code_scan.patches -gt 0
        }).Count -gt 0) { throw 'CLEAN_SUMMARY_PATCH_REPORT_CONTRADICTION' }
        $Event.status = 'SCANNED_CLEAN'; $Event.scan_completed = $true
        $Event.module_modified = $false
        # A clean process scan is not proof that the target module was loaded/covered.
        if ($canEstablishIntegrity) {
            $Event.target_module_modified = $false; $Event.target_function_modified = $false
            $Event.technique_observed = $false; $Event.patch_count = 0
        }
        return
    }
    if ($null -eq $report) { throw 'SUSPICIOUS_SCAN_REPORT_MISSING' }
    if ($null -eq $report.scans) { throw 'REPORT_SCANS_MISSING' }
    $Event.status = 'SCANNED_SUSPICIOUS'
    # Suspicious can also mean an inaccessible file; require actual modification
    # evidence for the generic module-modified field used by rule 100410.
    $modified = @($report.scans | Where-Object {
        ($null -ne $_.code_scan -and [int]$_.code_scan.status -eq 1 -and [int]$_.code_scan.patches -gt 0) -or
        ($null -ne $_.iat_scan -and [int]$_.iat_scan.status -eq 1 -and [int]$_.iat_scan.hooks -gt 0) -or
        ($null -ne $_.headers_scan -and [int]$_.headers_scan.status -eq 1)
    })
    $Event.module_modified = $modified.Count -gt 0
    $expectedModule = $Event.target_module
    $targetScans = @($report.scans | Where-Object {
        $null -ne $_.code_scan -and
        [string]$_.code_scan.module_file -ieq $expectedModule -and
        [int]$_.code_scan.status -eq 1 -and [int]$_.code_scan.patches -gt 0
    })
    if ($targetScans.Count -eq 0) {
        if (@($coveredCode | Where-Object { [int]$_.code_scan.status -ne 0 }).Count -gt 0) { throw 'TARGET_CODE_SCAN_INCONSISTENT' }
        $Event.scan_completed = $true
        if ($canEstablishIntegrity) {
            $Event.target_module_modified = $false; $Event.target_function_modified = $false; $Event.technique_observed = $false
        }
        return
    }
    if ($targetScans.Count -ne 1) { throw 'AMBIGUOUS_TARGET_REPORT' }
    if ($Event.scan_report_mode -eq 'ALL' -and $coveredCode.Count -ne 1) { throw 'TARGET_CODE_SCAN_NOT_VERIFIED' }
    $code = $targetScans[0].code_scan
    $Event.module = [string]$code.module_file; $Event.module_base = [string]$code.module
    $Event.target_module_observed = $true; $Event.target_module_modified = $true
    $Event.patch_count = [int]$code.patches; $Event.status = 'SCANNED_TARGET_MODULE_MODIFIED'
    # Match the tag's base address to the modified module; do not take an unrelated tag.
    $baseKey = ([string]$code.module -replace '^0x','').TrimStart('0').ToLowerInvariant()
    $tags = @(Get-ChildItem -LiteralPath $ProcessDirectory -File -Filter ('*.' + [System.IO.Path]::GetFileName($Event.target_module) + '.tag') -ErrorAction SilentlyContinue |
        Where-Object { (($_.Name.Split('.')[0] -replace '^0x','').TrimStart('0').ToLowerInvariant()) -eq $baseKey })
    if ($tags.Count -ne 1) { throw 'TARGET_TAG_MISSING_OR_AMBIGUOUS' }
    $Event.tag_file = $tags[0].FullName
    $found = @()
    foreach ($line in Get-Content -LiteralPath $Event.tag_file) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $parts = $line.Split(';')
        if ($parts.Count -ne 3 -or $parts[0].Trim() -notmatch '^(0x)?[0-9a-fA-F]+$' -or
            $parts[2].Trim() -notmatch '^(0x)?[0-9a-fA-F]+$' -or
            [Convert]::ToInt32(($parts[2].Trim() -replace '^0x',''), 16) -le 0) { throw 'MALFORMED_TAG' }
        if ($parts[1].Trim() -ceq $Event.target_function) { $found += ,$parts }
    }
    if ($found.Count -gt 1) { throw 'AMBIGUOUS_FUNCTION_TAG' }
    $Event.target_function_modified = $null; $Event.technique_observed = $false
    if ($found.Count -eq 0) { $Event.error = 'TARGET_FUNCTION_NOT_RESOLVED_IN_TAG' }
    if ($found.Count -eq 1) {
        $Event.function = $Event.target_function; $Event.patch_rva = $found[0][0].Trim()
        $Event.patch_size = [Convert]::ToInt32(($found[0][2].Trim() -replace '^0x',''), 16); $Event.target_function_modified = $true
        $Event.technique_observed = $true; $Event.technique_id = $Event.target_technique_id
        $Event.status = 'SCANNED_TARGET_FUNCTION_PATCHED'
    }
    $Event.scan_completed = $true
}

function Update-MemoryCompatibilityAliases {
    param([System.Collections.IDictionary]$Event)
    if ($Event.status -eq 'SCANNED_AMSI_MODULE_MODIFIED') { $Event.status = 'SCANNED_TARGET_MODULE_MODIFIED' }
    if ($Event.status -eq 'SCANNED_AMSI_SCANBUFFER_PATCHED') { $Event.status = 'SCANNED_TARGET_FUNCTION_PATCHED' }
    $Event.generic_status = $Event.status
    if ([System.IO.Path]::GetFileName($Event.target_module) -ieq 'amsi.dll' -and
        $Event.target_function -ceq 'AmsiScanBuffer' -and $Event.target_technique_id -eq 'T1562.001') {
        $Event.amsi_module_ready = $Event.target_module_ready
        $Event.amsi_module_observed = $Event.target_module_observed
        $Event.amsi_coverage_evidence = $Event.target_coverage_evidence
        $Event.amsi_modified = $Event.target_module_modified
        $Event.amsi_scanbuffer_modified = $Event.target_function_modified
        if ($Event.status -eq 'SCANNED_TARGET_MODULE_MODIFIED') { $Event.status = 'SCANNED_AMSI_MODULE_MODIFIED' }
        if ($Event.status -eq 'SCANNED_TARGET_FUNCTION_PATCHED') { $Event.status = 'SCANNED_AMSI_SCANBUFFER_PATCHED' }
    }
}

function Convert-PeSieveEvidence {
    param([System.Collections.IDictionary]$Event, [string]$ConsoleText, [string]$ProcessDirectory)
    try { Convert-PeSieveEvidenceCore -Event $Event -ConsoleText $ConsoleText -ProcessDirectory $ProcessDirectory }
    finally {
        $Event.target_scan_completed=($Event.scan_completed -eq $true -and $Event.target_integrity_verified -eq $true)
        if ($null -ne $Event.scan_errors -and $Event.scan_errors -gt 0) {
            if ($Event.target_scan_completed -and $Event.target_module_modified -eq $true) {
                $Event.warnings += 'GLOBAL_SCAN_INCOMPLETE_TARGET_POSITIVE_VERIFIED'
                # Preserve observed modification; never claim global completion.
            } else {
                if ($Event.target_scan_completed) { $Event.warnings += 'GLOBAL_SCAN_INCOMPLETE_TARGET_NEGATIVE_VERIFIED' }
                $Event.status='SCAN_ERROR'; $Event.module_modified=$null
            }
            $Event.scan_completed=$false; $Event.error='INCOMPLETE_SCAN_ERRORS'
        }
        Update-MemoryCompatibilityAliases -Event $Event
    }
}

function Invoke-MemorySensorScan {
    $event = New-MemoryObservation -ProcessId $TargetPid -RunIdentifier $RunId
    $event.scan_group_id = $event.scan_id
    $readyModules = @{}
    $scanner = $null
    $scannerStarted = $false
    $outTask = $null; $errTask = $null; $consoleText = ''
    $processReportDirectory = $null
    try {
        if ($TargetPid -le 0) { throw 'INVALID_PID' }
        if (-not (Test-Path -LiteralPath $PeSievePath -PathType Leaf)) { throw 'PE_SIEVE_NOT_FOUND' }
        $target = Get-Process -Id $TargetPid -ErrorAction SilentlyContinue
        if ($null -eq $target) {
            $event.status = 'TARGET_TERMINATED_BEFORE_SCAN'; $event.error = 'TARGET_NOT_RUNNING'
        } else {
            $event.process_start_utc = $target.StartTime.ToUniversalTime().ToString('o')
            if ($ExpectedProcessStartUTC -and
                ([datetimeoffset]::Parse($ExpectedProcessStartUTC).UtcDateTime -ne $target.StartTime.ToUniversalTime())) {
                throw 'PID_REUSED_PROCESS_START_MISMATCH'
            }
            try { $event.image = $target.Path } catch {}
            $readyClock = [System.Diagnostics.Stopwatch]::StartNew()
            # Same bounded module-readiness policy for every enabled tier. No patch
            # polling and no modification/suspension of the target process.
            do {
                if ($target.HasExited) {
                    $event.status = 'TARGET_TERMINATED_BEFORE_SCAN'
                    throw 'TARGET_EXITED_DURING_READINESS'
                }
                try {
                    $target.Refresh()
                    $expected = $Event.target_module
                    $loadedPaths = @($target.Modules | ForEach-Object { $_.FileName })
                    foreach ($module in @($TargetModule) + @($AdditionalTargets | ForEach-Object { $_.Module })) {
                        $readyModules[$module] = @($loadedPaths | Where-Object { $_ -ieq $module }).Count -gt 0
                    }
                    $event.target_module_ready = $readyModules[$expected]
                } catch { $event.target_module_ready = $null; break }
                if ((@($readyModules.Values | Where-Object { $_ -ne $true }).Count -eq 0 -and $readyModules.Count -gt 0) -or $readyClock.ElapsedMilliseconds -ge $ReadinessTimeoutMilliseconds) { break }
                Start-Sleep -Milliseconds 10
            } while ($true)
            $readyClock.Stop()
            $scanDir = Join-Path $WorkRoot ('s_' + $event.scan_id.Substring(0,12))
            New-Item -ItemType Directory -Path $scanDir -Force | Out-Null
            $event.work_dir = $scanDir
            $event.raw_output = Join-Path $scanDir 'pe-sieve-console.txt'
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $PeSievePath
            $psi.Arguments = Get-PeSieveArguments -ProcessId $TargetPid -ReportDirectory $scanDir -EnableThreads $ScanThreads -ObfuscationMode $ObfuscMode
            $event.scan_report_mode = 'ALL'
            $psi.WorkingDirectory = $scanDir; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
            $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
            $scanner = New-Object System.Diagnostics.Process; $scanner.StartInfo = $psi
            $event.scan_start_utc = [datetime]::UtcNow.ToString('o')
            if (-not $scanner.Start()) { throw 'SCANNER_START_FAILED' }
            $scannerStarted = $true
            $outTask = $scanner.StandardOutput.ReadToEndAsync()
            $errTask = $scanner.StandardError.ReadToEndAsync()
            if (-not $scanner.WaitForExit($TimeoutSeconds * 1000)) {
                try { $scanner.Kill(); $scanner.WaitForExit(2000) | Out-Null } catch {}
                $event.status = 'SCAN_ERROR'; $event.error = 'SCANNER_TIMEOUT'
            }
            if ($scanner.HasExited) { $event.pe_exit_code = $scanner.ExitCode }
            $event.scan_end_utc = [datetime]::UtcNow.ToString('o')
            $stdoutText = Get-MemoryOutputTaskText -ReadTask $outTask
            $stderrText = Get-MemoryOutputTaskText -ReadTask $errTask
            [IO.File]::WriteAllText((Join-Path $scanDir 'pe-sieve-stdout.txt'), $stdoutText, [Text.UTF8Encoding]::new($false))
            [IO.File]::WriteAllText((Join-Path $scanDir 'pe-sieve-stderr.txt'), $stderrText, [Text.UTF8Encoding]::new($false))
            $consoleText = $stdoutText + [Environment]::NewLine + $stderrText
            [IO.File]::WriteAllText($event.raw_output, $consoleText, [Text.UTF8Encoding]::new($false))
            if (-not $event.error) {
                $event.status = 'SCAN_ERROR'
                if ($consoleText -notmatch '(?im)SUMMARY\s*:') {
                    if ($null -eq (Get-Process -Id $TargetPid -ErrorAction SilentlyContinue)) {
                        $event.status = 'TARGET_TERMINATED_DURING_SCAN'; $event.error = 'TARGET_EXITED_WITHOUT_SUMMARY'
                    } elseif ($consoleText -match '(?i)access\s+denied|could not open the process.*error:\s*5\b') {
                        $event.status = 'SCAN_ACCESS_DENIED'; $event.error = 'PROCESS_ACCESS_DENIED'
                    } else { $event.error = 'SUMMARY_MISSING' }
                } elseif ($event.pe_exit_code -notin @(1,2)) { $event.error = 'UNEXPECTED_PE_EXIT_CODE' }
                else {
                    try {
                        $processReportDirectory = Find-PeSieveProcessDirectory -ScanDirectory $scanDir -ProcessId $TargetPid
                        Convert-PeSieveEvidence -Event $event -ConsoleText $consoleText -ProcessDirectory $processReportDirectory
                    } catch {
                        $event.error = $_.Exception.Message
                        $event.status = if ($event.error -eq 'INCOMPLETE_SCAN_ERRORS') { 'SCAN_ERROR' } else { 'REPORT_PARSE_ERROR' }
                        $event.scan_completed = $false
                        $event.module_modified = $null; $event.target_module_modified = $null
                        $event.target_function_modified = $null; $event.technique_observed = $null
                    }
                }
            }
        }
    } catch { $event.error = $_.Exception.GetBaseException().Message; $event.status = 'SCAN_ERROR' }
    finally {
        if ($null -ne $scanner) {
            if ($scannerStarted) { try { if (-not $scanner.HasExited) { $scanner.Kill(); $scanner.WaitForExit(2000) | Out-Null } } catch {} }
            # Keep available output even when startup/wait/parsing fails.
            foreach ($capture in @(@{Task=$outTask; Name='pe-sieve-stdout.txt'}, @{Task=$errTask; Name='pe-sieve-stderr.txt'})) {
                if ($null -ne $capture.Task -and $event.work_dir) {
                    try {
                        if ($capture.Task.Wait(500) -and -not $capture.Task.IsFaulted -and -not $capture.Task.IsCanceled) {
                            [IO.File]::WriteAllText((Join-Path $event.work_dir $capture.Name), [string]$capture.Task.Result, [Text.UTF8Encoding]::new($false))
                        }
                    } catch { $event.warnings += ('OUTPUT_PRESERVATION_FAILED: ' + $_.Exception.GetBaseException().Message) }
                }
            }
            $scanner.Dispose()
        }
    }
    Update-MemoryCompatibilityAliases -Event $event
    if ($event.target_module_ready -eq $false) { $event.warnings += 'TARGET_MODULE_NOT_READY_AT_DEADLINE' }
    if ($event.scan_completed -and $event.target_module_observed -ne $true) {
        $event.warnings += 'TARGET_MODULE_COVERAGE_UNVERIFIED'
    }
    # Derive each target from the SAME scanner output. Failure or absence for
    # one target is never evidence that the other target is unmodified.
    $observations = @($event)
    foreach ($configuration in @($AdditionalTargets)) {
        if (-not $configuration.Module -or -not $configuration.Function -or
            $configuration.TechniqueId -notmatch '^T[0-9]{4}\.[0-9]{3}$') { throw 'INVALID_ADDITIONAL_TARGET' }
        $other = New-MemoryObservation -ProcessId $TargetPid -RunIdentifier $RunId
        $other.target_module = $configuration.Module; $other.target_function = $configuration.Function
        $other.target_technique_id = $configuration.TechniqueId; $other.scan_group_id = $event.scan_group_id
        foreach ($key in @('image','process_start_utc','scan_start_utc','scan_end_utc','pe_exit_code','work_dir','raw_output','scan_report_mode','scan_threads_enabled','scan_obfusc_mode')) { $other[$key] = $event[$key] }
        $other.target_module_ready = $readyModules[$configuration.Module]
        $other.status = $event.status; $other.error = $event.error
        if ($scannerStarted -and $event.pe_exit_code -in @(1,2) -and $consoleText -match '(?im)SUMMARY\s*:' -and $event.error -notin @('SCANNER_TIMEOUT','SCANNER_OUTPUT_TIMEOUT')) {
            $other.error = $null
            try {
                if (-not $processReportDirectory) { $processReportDirectory = Find-PeSieveProcessDirectory -ScanDirectory $event.work_dir -ProcessId $TargetPid }
                Convert-PeSieveEvidence -Event $other -ConsoleText $consoleText -ProcessDirectory $processReportDirectory
            }
            catch {
                $other.error = $_.Exception.Message
                $other.status = if ($other.error -eq 'INCOMPLETE_SCAN_ERRORS') { 'SCAN_ERROR' } else { 'REPORT_PARSE_ERROR' }
                $other.scan_completed = $false; $other.module_modified = $null
                $other.target_module_modified = $null; $other.target_function_modified = $null; $other.technique_observed = $null
            }
        }
        Update-MemoryCompatibilityAliases -Event $other
        if ($other.target_module_ready -eq $false) { $other.warnings += 'TARGET_MODULE_NOT_READY_AT_DEADLINE' }
        if ($other.scan_completed -and $other.target_module_observed -ne $true) { $other.warnings += 'TARGET_MODULE_COVERAGE_UNVERIFIED' }
        $observations += ,$other
    }
    foreach ($observation in $observations) {
        $observation.timestamp = [datetime]::UtcNow.ToString('o')
        $observation.publication_status = 'PUBLISHED'
        try { Write-SharedJsonLine -Path $OutputLog -Json ($observation | ConvertTo-Json -Depth 8 -Compress) }
        catch { $observation.publication_status = 'WRITE_ERROR'; $observation.publication_error = $_.Exception.Message }
    }
    $result = if ($AdditionalTargets.Count -gt 0) {
        [ordered]@{ schema_version='2.1'; scan_group_id=$event.scan_group_id; observations=@($observations) }
    } else { $event }
    if ($ResultPath) {
        $parent = Split-Path -Parent $ResultPath
        if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        [System.IO.File]::WriteAllText($ResultPath, ($result | ConvertTo-Json -Depth 10), [System.Text.UTF8Encoding]::new($false))
    }
    return [pscustomobject]$result
}

# Compile during preload, before the target starts; this never executes a scan.
Initialize-MemoryOutputPump
# Dot-sourcing exposes pure parsing functions for fixture tests without scanning.
if ($MyInvocation.InvocationName -ne '.') {
    Invoke-MemorySensorScan | ConvertTo-Json -Depth 8 -Compress | Write-Output
}
