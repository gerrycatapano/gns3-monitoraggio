﻿#requires -Version 5.1
<#
.SYNOPSIS
    Read-only, single-PID Moneta IOC observation for the GNS3 Windows-HR lab.
.DESCRIPTION
    Runs one Moneta64.exe scan for one PID (no dumps, no process changes), preserves
    raw evidence, and emits schema_version=2.2 JSON compatible with the HR telemetry
    layout. Fail closed: missing/malformed output and failed scans are not CLEAN.
    Does not assert function-level or DLL-integrity evidence: Moneta is an IOC scanner.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateRange(1,2147483647)][int]$TargetPid,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z]:\\')][string]$TargetModule,
    [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$TargetFunction,
    [Parameter(Mandatory=$true)][ValidatePattern('^T[0-9]{4}\.[0-9]{3}$')][string]$TechniqueId,
    [string]$MonetaPath = 'C:\Tools\Moneta64.exe',
    [string]$OutputLog = 'C:\ProgramData\ThesisTelemetry\memory_integrity.json',
    [string]$WorkRoot = 'C:\ProgramData\ThesisTelemetry\moneta-work',
    [string]$RunId = '',
    [string]$ResultPath = '',
    [ValidateRange(1,120)][int]$TimeoutSeconds = 20,
    [string]$ExpectedProcessStartUTC = ''
)
$ErrorActionPreference = 'Stop'

function New-MonetaObservation {
    param([int]$ProcessId, [string]$Run)
    return [ordered]@{
        schema_version='2.2'; timestamp=$null; source='memory_integrity'; sensor='moneta'
        run_id=$Run; scan_id=[guid]::NewGuid().ToString('N'); scan_group_id=$null
        pid=$ProcessId; image=$null; process_start_utc=$null
        target_module=$TargetModule; target_function=$TargetFunction; target_technique_id=$TechniqueId
        # Moneta is process-wide. These are deliberately unknown, not false.
        target_module_observed=$null; target_module_modified=$null
        target_function_modified=$null; technique_observed=$null
        target_scan_completed=$null; target_integrity_verified=$null
        status='SENSOR_ERROR'; generic_status='SENSOR_ERROR'; scan_completed=$false
        ioc_count=$null; scan_result_source='NOT_VERIFIED'; moneta_exit_code=$null
        scan_start_utc=$null; scan_end_utc=$null; work_dir=$null
        raw_output=$null; raw_stderr=$null
        error=$null; warnings=@(); publication_status='NOT_ATTEMPTED'
        publication_error=$null
    }
}

function Convert-MonetaConsoleEvidence {
    <#
      The Moneta 2024 source prints '... scan completed (N second duration)' on
      the path after successful/failed Enumerate; hence it is NOT sufficient
      alone. 'Memory statistics' is produced by ShowRecords() only if process
      Enumerate() returned and --option statistics was supplied.
      'IOC statistics [N total]' is printed only for N > 0.
      A clean result requires both end marker and memory statistics.
    #>
    param([string]$Stdout, [int]$ExitCode)
    # Versions/builds may report 0 or 1 after a completed scan. The code is
    # never used alone to declare success: terminal markers and statistics are
    # mandatory, and every other exit code remains an explicit SCAN_ERROR.
    if ($ExitCode -notin @(0,1)) { throw 'MONETA_UNEXPECTED_EXIT_CODE' }
    if ([string]::IsNullOrWhiteSpace($Stdout)) { throw 'MONETA_EMPTY_OUTPUT' }
    if ($Stdout -match '(?im)failed to map address space|invalid (?:target|memory)|scanner cannot target itself|address must be specified|should not be used on a 64-bit OS') {
        throw 'MONETA_SCAN_ERROR_OUTPUT'
    }
    if ($Stdout -notmatch '(?im)^\s*\.\.\.\s*scan completed\s*\(\s*\d+(?:\.\d+)?\s+second duration\)\s*$') {
        throw 'MONETA_COMPLETION_MARKER_MISSING'
    }
    if ($Stdout -notmatch '(?im)^\s*Memory statistics\s*$') {
        throw 'MONETA_MEMORY_STATISTICS_MISSING'
    }
    # A bare heading is insufficient to claim a successful, clean scan.
    if ($Stdout -notmatch '(?im)^\s*PAGE_(?:READONLY|READWRITE|EXECUTE_READ|NOACCESS):\s*\d+\s*\(') {
        throw 'MONETA_MEMORY_STATISTICS_INCOMPLETE'
    }
    # Explicit error indicators take precedence over any completion marker.
    if ($Stdout -match '(?im)failed to (?:query thread information|open handle|create process list snapshot)|cancelling scan of process') {
        throw 'MONETA_SCAN_ERROR_OUTPUT'
    }
    $counts = @([regex]::Matches($Stdout, '(?im)IOC statistics\s*\[\s*([0-9]+)\s+total\s*\]'))
    if ($counts.Count -gt 1) { throw 'MONETA_DUPLICATE_IOC_SUMMARY' }
    if ($Stdout -match '(?im)IOC statistics' -and $counts.Count -eq 0) {
        throw 'MONETA_IOC_FORMAT_UNRECOGNIZED'
    }
    if ($counts.Count -eq 1) {
        $iocCount = [int]$counts[0].Groups[1].Value
        if ($iocCount -le 0) { throw 'MONETA_INVALID_IOC_SUMMARY' }
        return @{ status='SCANNED_SUSPICIOUS'; ioc_count=$iocCount }
    }
    return @{ status='SCANNED_CLEAN'; ioc_count=0 }
}

function Write-MonetaJsonLine {
    param([string]$Path, [string]$Json)
    $parent = Split-Path -Parent $Path
    if ($parent) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes($Json + "`n")
    for ($attempt=0; $attempt -lt 5; $attempt++) {
        $stream = $null
        try {
            $stream = [IO.FileStream]::new($Path, [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::ReadWrite)
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Flush()
            return
        } catch [IO.IOException] {
            if ($attempt -eq 4) { throw }
            Start-Sleep -Milliseconds 100
        } finally {
            if ($null -ne $stream) { $stream.Dispose() }
        }
    }
}

function Invoke-MonetaMemorySensor {
    $ob = New-MonetaObservation -ProcessId $TargetPid -Run $RunId
    $ob.scan_group_id = $ob.scan_id
    $scanner = $null
    try {
        if (-not (Test-Path -LiteralPath $MonetaPath -PathType Leaf)) { throw 'MONETA_NOT_FOUND' }
        $target = Get-Process -Id $TargetPid -ErrorAction SilentlyContinue
        if ($null -eq $target) { throw 'TARGET_NOT_RUNNING' }
        $ob.process_start_utc = $target.StartTime.ToUniversalTime().ToString('o')
        try { $ob.image = $target.Path } catch { }
        if ($ExpectedProcessStartUTC -and
            [DateTimeOffset]::Parse($ExpectedProcessStartUTC).UtcDateTime -ne $target.StartTime.ToUniversalTime()) {
            throw 'PID_REUSED_PROCESS_START_MISMATCH'
        }
        $dir = Join-Path $WorkRoot ('pid{0}_{1}_{2}' -f $TargetPid, [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ'), $ob.scan_id)
        [void](New-Item -ItemType Directory -Path $dir -Force)
        $ob.work_dir = $dir
        $ob.raw_output = Join-Path $dir 'moneta-stdout.txt'
        $ob.raw_stderr = Join-Path $dir 'moneta-stderr.txt'

        $psi = [Diagnostics.ProcessStartInfo]::new()
        $psi.FileName = $MonetaPath
        $psi.Arguments = '-m ioc -p ' + $TargetPid + ' --option statistics'
        $psi.WorkingDirectory = $dir
        $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
        $scanner = [Diagnostics.Process]::new()
        $scanner.StartInfo = $psi
        $ob.scan_start_utc = [DateTime]::UtcNow.ToString('o')
        if (-not $scanner.Start()) { throw 'MONETA_START_FAILED' }
        $stdoutTask = $scanner.StandardOutput.ReadToEndAsync()
        $stderrTask = $scanner.StandardError.ReadToEndAsync()
        if (-not $scanner.WaitForExit($TimeoutSeconds * 1000)) {
            try { $scanner.Kill(); [void]$scanner.WaitForExit(2000) } catch { }
            throw 'MONETA_TIMEOUT'
        }
        $ob.moneta_exit_code = $scanner.ExitCode
        $ob.scan_end_utc = [DateTime]::UtcNow.ToString('o')
        if (-not $stdoutTask.Wait(2000) -or -not $stderrTask.Wait(2000)) { throw 'MONETA_OUTPUT_TIMEOUT' }
        $stdout = $stdoutTask.Result; $stderr = $stderrTask.Result
        # Preserve stdout/stderr even if parsing or classification fails.
        [IO.File]::WriteAllText($ob.raw_output, $stdout, [Text.UTF8Encoding]::new($false))
        [IO.File]::WriteAllText($ob.raw_stderr, $stderr, [Text.UTF8Encoding]::new($false))
        if ($stdout.Length -gt 33554432 -or $stderr.Length -gt 33554432) { throw 'MONETA_OUTPUT_TOO_LARGE' }
        if ($stderr -match '(?im)\b(error|failed|exception)\b') { throw 'MONETA_STDERR_REPORTED_ERROR' }
        $parsed = Convert-MonetaConsoleEvidence -Stdout $stdout -ExitCode $scanner.ExitCode
        # Identity check after scanner finishes: never attribute an old PID to a new process.
        $after = Get-Process -Id $TargetPid -ErrorAction SilentlyContinue
        if ($null -eq $after) { throw 'TARGET_EXITED_DURING_SCAN' }
        if ($after.StartTime.ToUniversalTime() -ne $target.StartTime.ToUniversalTime()) { throw 'PID_REUSED_DURING_SCAN' }
        $ob.status = $parsed.status
        $ob.ioc_count = $parsed.ioc_count
        $ob.scan_completed = $true
        $ob.scan_result_source = 'MONETA_IOC_STATISTICS'
    } catch {
        $ob.error = $_.Exception.Message
        $ob.status = 'SCAN_ERROR'
        $ob.scan_completed = $false
        $ob.ioc_count = $null
    } finally {
        if ($null -ne $scanner) {
            try { if (-not $scanner.HasExited) { $scanner.Kill(); [void]$scanner.WaitForExit(2000) } } catch { }
            # Preserve available stdout/stderr even for timeout or parse errors.
            foreach ($capture in @(
                @{ Task = (Get-Variable stdoutTask -ValueOnly -ErrorAction SilentlyContinue); Path = $ob.raw_output },
                @{ Task = (Get-Variable stderrTask -ValueOnly -ErrorAction SilentlyContinue); Path = $ob.raw_stderr }
            )) {
                if ($capture.Path -and -not (Test-Path -LiteralPath $capture.Path) -and $null -ne $capture.Task) {
                    try {
                        if ($capture.Task.Wait(2000)) {
                            [IO.File]::WriteAllText($capture.Path, $capture.Task.Result, [Text.UTF8Encoding]::new($false))
                        }
                    } catch { $ob.warnings += 'PARTIAL_OUTPUT_NOT_SAVED' }
                }
            }
            $scanner.Dispose()
        }
        if (-not $ob.scan_end_utc -and $ob.scan_start_utc) { $ob.scan_end_utc = [DateTime]::UtcNow.ToString('o') }
        $ob.timestamp = [DateTime]::UtcNow.ToString('o')
        $ob.generic_status = $ob.status
        $ob.publication_status = 'PUBLISHED'
        try { Write-MonetaJsonLine -Path $OutputLog -Json ($ob | ConvertTo-Json -Depth 8 -Compress) }
        catch { $ob.publication_status='WRITE_ERROR'; $ob.publication_error=$_.Exception.Message }
        if ($ResultPath) {
            $parent = Split-Path -Parent $ResultPath
            if ($parent) { [void](New-Item -ItemType Directory -Path $parent -Force) }
            [IO.File]::WriteAllText($ResultPath, ($ob | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
        }
    }
    return [pscustomobject]$ob
}

# Dot source for parser-only fixtures; never start scans on import.
if ($MyInvocation.InvocationName -ne '.') {
    Invoke-MonetaMemorySensor | ConvertTo-Json -Depth 8 -Compress | Write-Output
}
