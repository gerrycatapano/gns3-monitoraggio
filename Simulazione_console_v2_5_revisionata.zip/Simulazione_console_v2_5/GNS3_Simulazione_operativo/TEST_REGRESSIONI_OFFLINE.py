#!/usr/bin/env python3
"""Pure Python regression checks; no scanner, firewall, network or VM actions."""
import importlib.util
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('hr_gns3', ROOT / 'orchestratore_hr_gns3.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

with tempfile.TemporaryDirectory() as td:
    path = Path(td) / 'config.json'
    cfg = json.loads((ROOT / 'config_hr.json').read_text())
    cfg['priority_image_names'] = ['ExampleTest.exe']
    path.write_text(json.dumps(cfg))
    conf = mod.load_config(path)
    assert conf['priority_image_names'] == ['ExampleTest.exe']
    assert conf['pe_sieve_threads'] is True and conf['pe_sieve_obfusc_mode'] == 3
    for bad in (-1,4,True,'3'):
        wrong = {**cfg, 'pe_sieve_obfusc_mode': bad}
        path.write_text(json.dumps(wrong))
        try:mod.load_config(path)
        except ValueError:pass
        else:raise AssertionError('invalid obfuscation mode accepted: ' + repr(bad))
    wrong = {**cfg, 'priority_image_names': ['..\\not-allowed']}
    path.write_text(json.dumps(wrong))
    try:mod.load_config(path)
    except ValueError:pass
    else:raise AssertionError('invalid priority name accepted')

m = mod.Monitor.__new__(mod.Monitor)
m.cfg = {'priority_burst':3}
m.modes = ('pe-sieve','moneta')
m.new_streak = 0
m.pending = {}
m.running = {}
m.coverage = {}
m.known = {}
for pid, name, prio in ((100,'system.exe',False),(200,'ExampleTest.exe',True)):
    key = (pid,pid)
    m.known[key] = {'explicit_priority':prio, 'discovered_after_initial':False,
                    'script_host':False, 'watch_until':0}
    m.coverage[key] = {'sensors':{'pe-sieve':{'attempted':0,'errors':0,'completed':0},
                                 'moneta':{'attempted':0,'errors':0,'completed':0}}}
    task = (pid,pid,'pe-sieve')
    m.pending[task] = {'due':0}
assert m.select_task(list(m.pending)) == (200,200,'pe-sieve'), 'priority new process missed'
m.new_streak = 3
assert m.select_task(list(m.pending)) == (100,100,'pe-sieve'), 'fairness oldest first-pass missed'
print('PASS  Config bounds, scanner options, process priority and fairness (offline)')
