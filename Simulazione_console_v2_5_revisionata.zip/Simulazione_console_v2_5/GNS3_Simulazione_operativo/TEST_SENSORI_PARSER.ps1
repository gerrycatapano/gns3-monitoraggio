﻿#requires -Version 5.1
<#
.SYNOPSIS
    Read-only regression fixtures for Moneta parsing and PE-sieve arguments.
.DESCRIPTION
    Does not invoke an EXE or start any memory scan; requires PowerShell 5.1.
#>
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $here 'sensors\Invoke-MonetaMemorySensor.ps1') -TargetPid 1234 -TargetModule 'C:\Windows\System32\ntdll.dll' -TargetFunction 'NtTraceEvent' -TechniqueId 'T1562.006'
. (Join-Path $here 'sensors\Invoke-MemoryIntegritySensor.ps1') -TargetPid 1234 -TargetModule 'C:\Windows\System32\ntdll.dll' -TargetFunction 'NtTraceEvent' -TechniqueId 'T1562.006'
$tests = 0
function Assert-Equal {
    param($Actual, $Expected, [string]$Name)
    if ($Actual -ne $Expected) { throw ('FAIL ' + $Name + ': expected=' + $Expected + ', observed=' + $Actual) }
    $script:tests++
    Write-Host ('PASS  ' + $Name)
}
function Assert-Throws {
    param([scriptblock]$Action, [string]$Name)
    $threw = $false
    try { & $Action | Out-Null } catch { $threw = $true }
    if (-not $threw) { throw ('FAIL ' + $Name + ': non ha generato errore') }
    $script:tests++
    Write-Host ('PASS  ' + $Name)
}
# Representative console fragments, not real scanner output (must be validated on VM).
$clean = "... scan completed (0.12 second duration)`nMemory statistics`nPAGE_READONLY: 3 (12.0%)`n"
$suspicious = $clean + "IOC statistics [2 total]`n"
Assert-Equal (Convert-MonetaConsoleEvidence -Stdout $clean -ExitCode 1).status 'SCANNED_CLEAN' 'Moneta CLEAN exit 1'
Assert-Equal (Convert-MonetaConsoleEvidence -Stdout $clean -ExitCode 0).status 'SCANNED_CLEAN' 'Moneta CLEAN exit 0'
Assert-Equal (Convert-MonetaConsoleEvidence -Stdout $suspicious -ExitCode 1).ioc_count 2 'Moneta IOC positivi'
Assert-Throws { Convert-MonetaConsoleEvidence -Stdout $clean -ExitCode 5 } 'Moneta exit code non atteso'
Assert-Throws { Convert-MonetaConsoleEvidence -Stdout 'Memory statistics' -ExitCode 1 } 'Moneta output incompleto'
Assert-Throws { Convert-MonetaConsoleEvidence -Stdout ($clean + 'IOC statistics [x total]') -ExitCode 1 } 'Moneta IOC formato ignoto'
Assert-Throws { Convert-MonetaConsoleEvidence -Stdout ($suspicious + '... failed to open handle to PID 1234') -ExitCode 1 } 'Moneta errore con marcatori presenti'
$argsFull = Get-PeSieveArguments -ProcessId 1234 -ReportDirectory 'C:\Work Dir' -EnableThreads $true -ObfuscationMode 3
if ($argsFull -notmatch '/threads' -or $argsFull -notmatch '/obfusc 3' -or -not $argsFull.Contains('"C:\Work Dir"')) {
    throw ('FAIL PE-sieve full args: ' + $argsFull)
}
$tests++; Write-Host 'PASS  PE-sieve argomenti estesi'
$argsBase = Get-PeSieveArguments -ProcessId 1234 -ReportDirectory 'C:\Work' -EnableThreads $false -ObfuscationMode 0
if ($argsBase -match '/threads|/obfusc') { throw ('FAIL PE-sieve default args: ' + $argsBase) }
$tests++; Write-Host 'PASS  PE-sieve argomenti base'
Write-Host "ESITO: PASS $tests fixtures, nessuno scanner avviato"
