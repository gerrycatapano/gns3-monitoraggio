#!/usr/bin/env python3
"""Read-only checks for the GNS3 Windows-HR package. No scanner is run."""
import ast
import base64
import hashlib
import json
import re
import struct
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parent
# Known SHA-256 of the two original executable files supplied with v2.3.
BINARY_HASHES = {
    "pe_sieve_path": "9f3ff2884a2c61006cd0a92b7572a815b8dc17012be7747a6abd6ca07c503a3b",
    "moneta_path": "245e9253cb2cfb6b14ad0c00f42ce880d366797d8c3a194d832f4f796874c8b4",
}
FAILURES = []


def check(name, condition, hint=""):
    print(("PASS" if condition else "FAIL") + "  " + name + (" - " + hint if not condition and hint else ""))
    if not condition:
        FAILURES.append(name)


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_constants(source):
    tree = ast.parse(source, filename="orchestratore_hr_gns3.py")
    result = {}
    for statement in tree.body:
        if isinstance(statement, ast.Assign) and isinstance(statement.value, ast.Constant):
            for target in statement.targets:
                if isinstance(target, ast.Name):
                    result[target.id] = statement.value.value
    return result


def resolve_config_path(value):
    # On Windows, pathlib recognizes both drive paths and relative '..\\' paths.
    if sys.platform == "win32":
        path = Path(value)
        return (path if path.is_absolute() else ROOT / path).resolve()
    # Useful also for a read-only Linux inspection of the original ZIP.
    if re.match(r"^[A-Za-z]:\\", str(value)):
        return None
    return (ROOT / str(value).replace("\\", "/")).resolve()


def main():
    print("Verifica locale GNS3 v2.5 (nessuna modifica, nessuna scansione)")
    check("Python >= 3.10", sys.version_info >= (3, 10))
    check("Python a 64 bit", struct.calcsize("P") * 8 == 64)
    source_path = ROOT / "orchestratore_hr_gns3.py"
    script = source_path.read_text(encoding="utf-8-sig")
    try:
        compile(script, str(source_path), "exec")
        constants = source_constants(script)
        check("Sintassi orchestratore Python", True)
    except (SyntaxError, ValueError) as exc:
        check("Sintassi orchestratore Python", False, str(exc))
        return 1
    check("Versione orchestratore 2.5", constants.get("VERSION") == "2.5.0-gns3-scanner-scheduling")
    for sensor, key in (("Invoke-MemoryIntegritySensor.ps1", "SENSOR_SHA256"),
                        ("Invoke-MonetaMemorySensor.ps1", "MONETA_SENSOR_SHA256")):
        path = ROOT / "sensors" / sensor
        check("Sensore " + sensor + " presente", path.is_file())
        if path.is_file():
            check("Hash sensore " + sensor, hash_file(path) == constants.get(key))
    try:
        check("Backup embedded PE-sieve coerente", hashlib.sha256(base64.b64decode(constants["SENSOR_B64"])).hexdigest() == constants["SENSOR_SHA256"])
    except (KeyError, ValueError) as exc:
        check("Backup embedded PE-sieve coerente", False, str(exc))
    try:
        xml_text = (ROOT / "local_rules.xml").read_text(encoding="utf-8-sig")
        rules = ET.fromstring("<root>" + xml_text + "</root>").findall(".//rule")
        ids = [r.get("id") for r in rules]
        check("XML regole ben formato, ID non duplicati", len(ids) == len(set(ids)))
        moneta = next(r for r in rules if r.get("id") == "100511")
        pe = next(r for r in rules if r.get("id") == "100510")
        check("Regola Moneta usa <status> statico", moneta.find("status") is not None and
              moneta.find("status").attrib.get("type") == "pcre2" and
              moneta.find("field[@name='status']") is None)
        check("Regola PE-sieve 100510 presente", pe.find("field[@name='sensor']") is not None)
    except (ET.ParseError, OSError, ValueError, StopIteration) as exc:
        check("Regole XML", False, str(exc))
    try:
        cfg = json.loads((ROOT / "config_hr.json").read_text(encoding="utf-8-sig"))
        check("IP Manager configurato", cfg["export"]["manager_host"] == "10.0.99.14")
        check("Agent ID configurato", str(cfg["export"]["agent_id"]) == "004")
        check("Opzioni PE-sieve esplicite", cfg.get("pe_sieve_threads") is True and cfg.get("pe_sieve_obfusc_mode") == 3)
        check("Timeout scanner/worker coerenti", 5 < cfg.get("scanner_timeout_seconds",0) < cfg.get("worker_timeout_seconds",0) - 5)
        check("Priorita per nome configurabile", isinstance(cfg.get("priority_image_names"),list))
        for key in ("pe_sieve_path", "moneta_path"):
            path = resolve_config_path(cfg.get(key, ""))
            check("Eseguibile " + key + " presente", path is not None and path.is_file(), str(path))
            if path is not None and path.is_file():
                check("Eseguibile " + key + " ha intestazione PE", path.read_bytes()[:2] == b"MZ")
                check("SHA-256 originale " + key, hash_file(path) == BINARY_HASHES[key],
                      "binario diverso dalla versione inclusa nello ZIP originale")
    except (OSError, KeyError, ValueError, TypeError) as exc:
        check("Configurazione scanner", False, str(exc))
    print("\nESITO:", "PASS controlli statici" if not FAILURES else "FAIL - " + ", ".join(FAILURES))
    print("NOTA: non certifica il funzionamento degli scanner, Wazuh o SSH sulla VM.")
    return 1 if FAILURES else 0


if __name__ == "__main__":
    sys.exit(main())
