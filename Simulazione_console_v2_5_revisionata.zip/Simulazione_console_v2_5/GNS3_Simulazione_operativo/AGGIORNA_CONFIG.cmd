@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0aggiorna_config_v22.py"
goto done
:python
python "%~dp0aggiorna_config_v22.py"
:done
pause
endlocal
