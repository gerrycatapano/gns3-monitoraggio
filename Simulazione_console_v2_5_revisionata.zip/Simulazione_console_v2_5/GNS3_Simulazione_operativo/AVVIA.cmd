@echo off
setlocal
cd /d "%~dp0"
echo Avvio monitoraggio Windows-HR con pe-sieve e Moneta v2.5.
echo Usare Esegui come amministratore per questo file.
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 "%~dp0orchestratore_hr_gns3.py" monitor --config "%~dp0config_hr.json"
goto finish
:use_python
where python >nul 2>nul
if errorlevel 1 goto missing_python
python "%~dp0orchestratore_hr_gns3.py" monitor --config "%~dp0config_hr.json"
goto finish
:missing_python
echo Python non trovato. Serve Python 3.10 o successivo a 64 bit.
:finish
echo.
echo Programma terminato. Leggere eventuali errori sopra.
pause
endlocal
