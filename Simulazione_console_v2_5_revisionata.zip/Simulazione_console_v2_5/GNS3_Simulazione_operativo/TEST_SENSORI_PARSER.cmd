@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0TEST_SENSORI_PARSER.ps1"
set EXIT_CODE=%ERRORLEVEL%
echo.
if not "%EXIT_CODE%"=="0" echo FAIL - Controlli PowerShell non superati.
pause
exit /b %EXIT_CODE%
