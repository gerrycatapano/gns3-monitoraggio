from pathlib import Path
from datetime import datetime
import json, shutil, os
p=Path(__file__).resolve().with_name('config_hr.json')
data=json.loads(p.read_text(encoding='utf-8-sig'))
if not isinstance(data,dict): raise ValueError('Configurazione non valida')
backup=p.with_name(p.name+'.backup-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
shutil.copy2(p,backup)
data.update({'output_root': 'C:\\GNS3Runs', 'inventory_seconds': 1, 'max_concurrent_scans': 2, 'new_process_watch_seconds': 30, 'new_process_rescan_seconds': 5, 'priority_burst': 3})
temp=p.with_name(p.name+'.v22.tmp')
temp.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
os.replace(temp,p)
print('Configurazione aggiornata, export e target conservati. Backup:',backup)
