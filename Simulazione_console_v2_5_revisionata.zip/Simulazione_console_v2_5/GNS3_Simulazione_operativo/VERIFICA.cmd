@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0VERIFICA_OFFLINE.py"
    goto end
)
where python >nul 2>nul
if not errorlevel 1 (
    python "%~dp0VERIFICA_OFFLINE.py"
    goto end
)
echo ERRORE: installare Python 3.10 o successivo (64 bit).
:end
pause
endlocal
