@echo off
setlocal
cd /d "%~dp0"
echo Solo esportazione degli alert. Nessuna nuova scansione.
set /p "SESSIONE=Incollare il percorso della sessione gia terminata: "
if not defined SESSIONE goto finish
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 "%~dp0orchestratore_hr_gns3.py" export --config "%~dp0config_hr.json" --session "%SESSIONE%"
goto finish
:use_python
python "%~dp0orchestratore_hr_gns3.py" export --config "%~dp0config_hr.json" --session "%SESSIONE%"
:finish
pause
endlocal
